
import { BsInstagram,BsTwitter,BsFacebook,BsGithub,BsLinkedin } from 'react-icons/bs';
function Social(){
    return (
        <div className="flex gap-2 text-center justify-center content-center pb-4">
               {/* <h1 className="text-red-700" >Hello Iam Social wala comp....</h1> */}
               {/* <BsLinkedin/><BsGithub/><HomeIcon/> */}
               {/* <PortfolioIcon/> */}
               {/* <HomeIcon/> */}
           <div className="bg-slate-900 p-2 rounded-full overflow-hidden relative"><BsInstagram/></div>
           <div className="bg-slate-900 p-2 rounded-full overflow-hidden relative"><BsTwitter/></div>
           <div className="bg-slate-900 p-2 rounded-full overflow-hidden relative"><BsFacebook/></div> 
           <div className="bg-slate-900 p-2 rounded-full overflow-hidden relative"><BsGithub/></div>
           <div className="bg-slate-900 p-2 rounded-full overflow-hidden relative"><BsLinkedin/></div>
        </div>
       
    );
}
export default Social;