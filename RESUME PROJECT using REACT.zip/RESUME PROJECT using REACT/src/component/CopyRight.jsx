function CopyRight(){
    return (

        <div>

        <footer className="pt-20 text-sm opacity-90">
          <h1 className="truncate py-2">© Copyright <span className="font-bold">Brain Mentor</span> </h1>
          <p>Designed by <a href="https://github.com/ShubhamPandey8756" className=" font-bold text-amber-600">SHUBHAM</a></p>
        </footer>
    
      </div>
        
    );
}
export default CopyRight;