import React from "react";
import Banner from './Banner';
import Technical from './Technical';
function ResumeComponent(){
    return(
        <div className=" flex flex-row h-screen bg-slate-900 font-mullish pt-8 pl-8  overflow-hidden justify-between gap-2 text-white">
            <div>
            <Technical></Technical>
            </div>
                <div className="">
                <Banner></Banner>
                </div>
                
        </div>
      
    );
}
export default ResumeComponent;