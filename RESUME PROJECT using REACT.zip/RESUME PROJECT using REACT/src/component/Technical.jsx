import Testimonial from './Testimonial';
import Social from './Social';
import Menu from './Menu';
import CopyRight from './CopyRight';
 function Technical(){
    return(
      <>
      <div >
        <Testimonial/>
      </div>
      <div className="technical flex flex-col pt-4">
             <Social/>
             <Menu/>
             <CopyRight/>
      </div>
      </>
      
      
    );
  }
  export default Technical;