import "./App.css";
import React from 'react';
import ResumeComponent from './component/ResumeComponent.jsx'
function App() {
  return (
    <div >
             <ResumeComponent/>
    </div>
  );
}

export default App;
