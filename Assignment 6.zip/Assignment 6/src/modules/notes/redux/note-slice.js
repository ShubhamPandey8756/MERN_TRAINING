import { createSlice } from "@reduxjs/toolkit";

const noteSlice = createSlice({
    name:'noteslice',
    initialState:{'notes':[], 'total':0,ascendingOrder:true,searchResult:[]},
    reducers:{
        // CRUD Operations
        // Sync Operations 
        // action - coming from the component 
        // state - update the centeralized store.
        addNote(state, action){
            const noteObject = action.payload;
            console.log('Add Note Reducer Operation Called.... ', action.payload);
            state.notes.push(noteObject);
            
        },
        getTotalRecords(state, action){
            state.total = state.notes.length;
        },
        removeNote(state, action){

        },
        searchNote(state, action) {
            const searchTerm = action.payload;
            state.searchResult = searchTerm ? state.notes.filter(note =>
              note.title.toLowerCase().includes(searchTerm.toLowerCase())
            ) : [];
            state.searchResult.push(searchTerm);
            console.log("search result is ", state.searchResult);
          },
        sortNote(state, action){
            // state.notes.sort((a,b)=>a.title.toLowerCase().localeCompare(b.title))
            // state.notes.map()
            state.notes.sort((a, b) => a.title.toLowerCase().localeCompare(b.title));
            state.ascendingOrder = !state.ascendingOrder; // Toggle the sorting order
            if (!state.ascendingOrder) {
              state.notes.reverse(); // Reverse the order if descending
            }
             
        },
        // toggleSwitch:(state)=>{
        //     state.active=!state.active;
        // },
    },
    extraReducers:{
        // Async Operations
    }
});
export const {addNote, removeNote, getNote,getTotalRecords,sortNote,searchNote} =  noteSlice.actions; // Component
export default  noteSlice.reducer;