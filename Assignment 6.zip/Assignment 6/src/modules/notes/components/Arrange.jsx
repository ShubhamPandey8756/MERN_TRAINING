import { useEffect } from "react";
import { List } from "./List";
import Button from '@mui/material/Button';
import { useDispatch , useSelector} from "react-redux";
import { getTotalRecords } from "../redux/note-slice";
import {sortNote} from "../redux/note-slice";

import Box from '@mui/material/Box';
export const Arrange=()=>{
    const dispatch=useDispatch();
    // const noteObject = useSelector(state=>{
    //     //console.log('*********** State is ', state);
    //     return {'notes':state.noteSlice.notes, 'total': state.noteSlice.total,'ascendingOrder': state.noteSlice.ascendingOrder };
    //     // return state.noteSlice.notes;
    //   });
    useEffect(()=>{
        // Component Mount
        console.log('Component Mount....');
        dispatch(getTotalRecords()); // Push
      },[]);
      const handelSort = ()=>{
        
        dispatch(sortNote());
       
      }
        
    return(
        <>
      <Button onClick={handelSort} variant="contained" color="success">
       Sort 
      </Button> 
      
      <List/>
      
        {/* dispatch(sortNote()); */}
        </>

    );
}